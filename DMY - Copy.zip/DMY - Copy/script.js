document.getElementById("startBtn").addEventListener("click", function() {
  alert("Let's get started with your classes!");
});

document.getElementById("playBtn").addEventListener("click", function() {
  alert("Play the intro video!");
});